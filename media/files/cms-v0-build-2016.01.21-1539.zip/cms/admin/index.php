<?php
header("Location: ../");
exit();
?>