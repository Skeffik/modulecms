<?php
//include protection
/*
 * Constant that is checked in included files to prevent direct access.
 * define() is used in the installation folder rather than "const" to not error for PHP 5.2 and lower
 */
defined('_CMSEXEC') or die('Restricted access');

function checkrequest($icheck){
	if (strpos($_SERVER['REQUEST_URI'],$icheck)) die(require_once ('engine/errors/404.html'));
}


?>